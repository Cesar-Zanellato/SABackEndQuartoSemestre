package com.back.fortesupermercados;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FortesupermercadosApplicationTests {

	@Test
	void contextLoads() {
	}

}
