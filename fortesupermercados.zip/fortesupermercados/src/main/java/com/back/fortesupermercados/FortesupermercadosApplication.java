package com.back.fortesupermercados;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FortesupermercadosApplication {

	public static void main(String[] args) {
		SpringApplication.run(FortesupermercadosApplication.class, args);
	}

}
